# README

This package animates the T-Sne algorithm as it advances